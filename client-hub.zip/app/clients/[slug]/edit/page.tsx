import { notFound } from "next/navigation";
import { getClient } from "@/lib/clients";
import ClientForm from "@/components/ClientForm";

export const dynamic = "force-dynamic";

export default function EditClientPage({
  params,
}: {
  params: { slug: string };
}) {
  const client = getClient(params.slug);
  if (!client) notFound();

  return (
    <div>
      <h1 className="text-2xl font-semibold text-ink">Edit {client.name}</h1>
      <p className="mt-1 text-sm text-inkfaint">
        Update their brand basics, social channels and reporting links.
      </p>
      <ClientForm initial={client} />
    </div>
  );
}
