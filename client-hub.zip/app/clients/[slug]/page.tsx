import Link from "next/link";
import { notFound } from "next/navigation";
import { getClient } from "@/lib/clients";
import StatusPill from "@/components/StatusPill";
import DeleteClientButton from "@/components/DeleteClientButton";

export const dynamic = "force-dynamic";

function ReportingRow({
  label,
  id,
  idLabel,
  url,
  clientId,
}: {
  label: string;
  id: string;
  idLabel: string;
  url: string;
  clientId: string;
}) {
  const connected = id.trim().length > 0;
  return (
    <div className="flex items-center justify-between gap-4 border-b border-line py-3 last:border-b-0">
      <div>
        <div className="text-sm text-ink">{label}</div>
        <div className="mt-0.5 font-mono text-xs text-inkfaint">
          {connected ? (
            <>
              {idLabel}: {id}
            </>
          ) : (
            "Not connected yet"
          )}
        </div>
      </div>
      {connected && url ? (
        <a
          href={url}
          target="_blank"
          rel="noreferrer"
          className="shrink-0 border border-ink px-3 py-1.5 text-xs text-ink hover:bg-ink hover:text-paper"
        >
          Open dashboard
        </a>
      ) : (
        <Link
          href={`/clients/${clientId}/edit`}
          className="shrink-0 text-xs text-inkfaint underline decoration-line underline-offset-4 hover:text-teal"
        >
          Add link
        </Link>
      )}
    </div>
  );
}

export default function ClientDetailPage({
  params,
}: {
  params: { slug: string };
}) {
  const client = getClient(params.slug);
  if (!client) notFound();

  return (
    <div>
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-semibold text-ink">{client.name}</h1>
            <StatusPill status={client.status} />
          </div>
          <p className="mt-1 text-sm text-inkfaint">{client.industry}</p>
          {client.primaryContact ? (
            <p className="mt-1 text-sm text-inkfaint">
              Primary contact: {client.primaryContact}
            </p>
          ) : null}
        </div>
        <div className="flex shrink-0 gap-2">
          <Link
            href={`/clients/${client.id}/edit`}
            className="border border-ink px-3 py-1.5 text-xs text-ink hover:bg-ink hover:text-paper"
          >
            Edit
          </Link>
          <DeleteClientButton id={client.id} />
        </div>
      </div>

      <section className="mt-10">
        <h2 className="text-sm font-medium text-ink">Social channels</h2>
        {client.socials.length === 0 ? (
          <p className="mt-2 text-sm text-inkfaint">
            No channels added yet.
          </p>
        ) : (
          <div className="mt-3 border-t border-line">
            {client.socials.map((s, i) => (
              <a
                key={i}
                href={s.url || undefined}
                target={s.url ? "_blank" : undefined}
                rel="noreferrer"
                className="flex items-center justify-between border-b border-line py-3 hover:bg-panel/60"
              >
                <span className="text-sm text-ink">{s.platform}</span>
                <span className="font-mono text-xs text-inkfaint">
                  {s.handle}
                </span>
              </a>
            ))}
          </div>
        )}
      </section>

      <section className="mt-10">
        <h2 className="text-sm font-medium text-ink">Reporting</h2>
        <div className="mt-3 border-t border-line">
          <ReportingRow
            label="Google Analytics 4"
            id={client.reporting.ga4.propertyId}
            idLabel="Property"
            url={client.reporting.ga4.url}
            clientId={client.id}
          />
          <ReportingRow
            label="Microsoft Clarity"
            id={client.reporting.clarity.projectId}
            idLabel="Project"
            url={client.reporting.clarity.url}
            clientId={client.id}
          />
          <ReportingRow
            label="Google Search Console"
            id={client.reporting.searchConsole.propertyUrl}
            idLabel="Property"
            url={client.reporting.searchConsole.url}
            clientId={client.id}
          />
        </div>
      </section>

      <section className="mt-10">
        <h2 className="text-sm font-medium text-ink">Notes</h2>
        <p className="mt-3 whitespace-pre-wrap text-sm leading-relaxed text-ink">
          {client.notes || "No notes yet."}
        </p>
      </section>
    </div>
  );
}
