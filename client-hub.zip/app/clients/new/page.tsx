import ClientForm from "@/components/ClientForm";

export default function NewClientPage() {
  return (
    <div>
      <h1 className="text-2xl font-semibold text-ink">Add a client</h1>
      <p className="mt-1 text-sm text-inkfaint">
        Set up their brand basics, social channels and reporting links.
      </p>
      <ClientForm />
    </div>
  );
}
