import { NextRequest, NextResponse } from "next/server";
import { deleteClient, getClient, updateClient } from "@/lib/clients";

export async function GET(
  _req: NextRequest,
  { params }: { params: { slug: string } }
) {
  const client = getClient(params.slug);
  if (!client) {
    return NextResponse.json({ error: "Not found." }, { status: 404 });
  }
  return NextResponse.json(client);
}

export async function PUT(
  req: NextRequest,
  { params }: { params: { slug: string } }
) {
  const body = await req.json();
  const client = updateClient(params.slug, body);
  if (!client) {
    return NextResponse.json({ error: "Not found." }, { status: 404 });
  }
  return NextResponse.json(client);
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: { slug: string } }
) {
  const ok = deleteClient(params.slug);
  if (!ok) {
    return NextResponse.json({ error: "Not found." }, { status: 404 });
  }
  return NextResponse.json({ ok: true });
}
