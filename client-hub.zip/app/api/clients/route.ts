import { NextRequest, NextResponse } from "next/server";
import { createClient, getClients } from "@/lib/clients";

export async function GET() {
  return NextResponse.json(getClients());
}

export async function POST(req: NextRequest) {
  const body = await req.json();

  if (!body.name || typeof body.name !== "string") {
    return NextResponse.json(
      { error: "A client name is required." },
      { status: 400 }
    );
  }

  const client = createClient({
    name: body.name,
    industry: body.industry ?? "",
    status: body.status ?? "onboarding",
    primaryContact: body.primaryContact ?? "",
    socials: body.socials ?? [],
    reporting: body.reporting,
    notes: body.notes ?? "",
  });

  return NextResponse.json(client, { status: 201 });
}
