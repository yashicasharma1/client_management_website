import Link from "next/link";

export default function NotFound() {
  return (
    <div className="py-10 text-center">
      <p className="text-ink">That client isn't on the roster.</p>
      <Link
        href="/"
        className="mt-4 inline-block border border-ink px-4 py-2 text-sm text-ink hover:bg-ink hover:text-paper"
      >
        Back to all clients
      </Link>
    </div>
  );
}
