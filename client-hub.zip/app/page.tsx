import Link from "next/link";
import { getClients } from "@/lib/clients";
import StatusPill from "@/components/StatusPill";
import ReportingDots from "@/components/ReportingDots";

export const dynamic = "force-dynamic";

export default function HomePage() {
  const clients = getClients();

  return (
    <div>
      <div className="flex items-baseline justify-between">
        <h1 className="text-2xl font-semibold text-ink">All clients</h1>
        <span className="font-mono text-xs text-inkfaint">
          {clients.length} on the roster
        </span>
      </div>

      {clients.length === 0 ? (
        <div className="mt-10 border border-dashed border-line px-6 py-10 text-center">
          <p className="text-ink">No clients yet.</p>
          <p className="mt-1 text-sm text-inkfaint">
            Add your first client to start tracking their handles and reporting links.
          </p>
          <Link
            href="/clients/new"
            className="mt-4 inline-block border border-ink px-4 py-2 text-sm text-ink hover:bg-ink hover:text-paper"
          >
            Add a client
          </Link>
        </div>
      ) : (
        <div className="mt-8 border-t border-line">
          {clients.map((client) => (
            <Link
              key={client.id}
              href={`/clients/${client.id}`}
              className="flex flex-col gap-2 border-b border-line py-4 hover:bg-panel/60 sm:flex-row sm:items-center sm:justify-between"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-3">
                  <span className="text-base font-medium text-ink">
                    {client.name}
                  </span>
                  <StatusPill status={client.status} />
                </div>
                <div className="mt-0.5 text-sm text-inkfaint">
                  {client.industry}
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div className="font-mono text-xs text-inkfaint">
                  {client.socials.length} channel
                  {client.socials.length === 1 ? "" : "s"}
                </div>
                <ReportingDots reporting={client.reporting} />
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
